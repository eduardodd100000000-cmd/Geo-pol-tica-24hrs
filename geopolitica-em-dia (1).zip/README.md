# Geopolítica em Dia 🌍

**Geopolítica em Dia** é um site de notícias focado em geopolítica global, inspirado no estilo da CNN.com.  
Traz atualizações sobre Brasil, EUA, China, Rússia, Ucrânia e Mundo.

## 🚀 Tecnologias
- HTML5
- CSS3 (responsivo, estilo inspirado na CNN)
- JavaScript (carrossel de manchetes)

## 🌐 Acesse o site
👉 [Geopolítica em Dia - GitHub Pages](https://seuusuario.github.io/geopolitica-em-dia)

## 📂 Estrutura
```
index.html   → Página principal  
styles.css   → Estilos do site  
README.md    → Documentação do projeto
```

## ✍️ Autor
Criado por **Eduardo Barros Ferreira**
